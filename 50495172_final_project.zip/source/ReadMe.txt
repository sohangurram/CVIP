Detect hand from using skin color
Kalman filter motion detection